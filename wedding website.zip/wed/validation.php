<?php
	session_start();
error_reporting(0);
	$email = $_POST['email'];
	$password = $_POST['password'];
	

        
	if($email=='admin@agro.com' && $password=='admin@123')
		
		header('location:admin.php');
	else
	{
	$conn = new mysqli('127.0.0.1','root','','project');
	if($conn->connect_error)
	{
		die('connection Failed :'.$conn->_error);
	}else
	{
		$stmt = $conn->prepare("select * from register where email = ?");
		$stmt->bind_param("s",$email);
		$stmt->execute();
		$stmt_result = $stmt->get_result();
		if($stmt_result->num_rows > 0){
			$data = $stmt_result->fetch_assoc();
			if($data['password']=== $password){
				
				$_SESSION['userid']=$data['id'];
				echo "<h2>LogIn Successfully</h2>";
				header('location:index.php');
			}else{
				echo "<h2>Invalid Email or PassWord</h2>";
			}
		}else{
			echo "<h2>Invalid Email or PassWord</h2>";
		}
		
		$stmt->close();
		$conn->close();
	}
	}
?>
	
	