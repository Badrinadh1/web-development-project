<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>
		contact us
	</title>
	<link rel="stylesheet" type="text/css" href="style4.css">
</head>
<body>
	        <header>
        <h1>wed-happy</h1>
        <nav>
            <ul class="nav-area">
<li><a href="index.php">home</a></li>
<li><a href="about.php">About</a></li>
<li><a href="services.php">services</a></li>
<li><a href="contact.php">contact</a></li>
<li><a href="our team.php">team</a></li>
</ul>
</nav>
        <a href="login.php" class="btn-area">login</a>
    </header>
<div class="container">
	<h1>connect with us</h1>
	<p>you can contact us personally about any wedding event</p>
	<div class="contact-box">
		<div class="contact-left">
			<h2>send your request</h2>
			<form >
				<div class="input-row">
					<div class="input-group">
						<label>user name</label>
						<input type="text" placeholder="username">
					</div>
					<div class="input-group">
						<label>Email</label>
						<input type="Email" placeholder="xyz@gmail.com">
					</div>
				</div>
				<div class="input-row">
     				<div class="input-group">
						<label>contact</label>
						<input type="contact" placeholder="+91 123 456 7890">
					</div>
					<div class="input-group">
						<label>subject</label>
						<input type="text" placeholder="...">
					</div>
				</div>
				<label>message</label>
				<textarea rows="10" placeholder="your text"></textarea>
				<button>submit</button>
			</form>
		</div>
		<div class="contact-right">
			<h2>way to  reach us</h2>
			<table>
				<tr>
					<td>email:</td>
					<td>shubhamrane@gmail.com</td>
				</tr>
				<tr>
					<td>contact:</td>
					<td>shubham rane:1234656799<br>badrinath:123456798</td>

				</tr>
				<tr>
					<td>address:</td>
					<td>xyx xyz xddgf fdhtd gf cffg gfhfdgsh hddfxgfcgfyz xyz</td>

				</tr>
			</table>

		</div>
	</div>
	
</div>
</body>
</html>