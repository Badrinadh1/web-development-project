<!DOCTYPE html>
<html>
<head>
        <meta charset="utf-8">
        <title>dd</title>
        <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
        <header>
        <h1>wed-happy</h1>
        <nav>
            <ul class="nav-area">
<li><a href="index.php">home</a></li>
<li><a href="about.php">About</a></li>
<li><a href="services.php">services</a></li>
<li><a href="contact.php">contact</a></li><li><a href="our team.php">team</a></li>
</ul>
</nav>
        <a href="login.php" class="btn-area">login</a>
    </header>
    <div class="banner">
            
    </div>
    <div class="footer">
            <h3 align="center"><a href="services.php">explore</a></h3>
           
    </div>

</body>
</html>