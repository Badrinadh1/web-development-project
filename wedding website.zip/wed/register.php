<?php
include 'Register.php'
?>


<!DOCTYPE html>
<html>
    <head>
        <title>MY website</title>
        <link rel="stylesheet" type="text/css" href="ppp.css">
    </head>
    <body> 

        <header>
        <h1>wed-happy</h1>
        <nav>
            <ul class="nav-area">
<li><a href="index.php">home</a></li>
<li><a href="about.php">About</a></li>
<li><a href="services.php">services</a></li>
<li><a href="contact.php">contact</a></li>
</ul>
</nav>
        <a href="login.php" class="btn-area">login</a>
    </header>



    <div class="wrapper">
        <div class="header1">
            <h2>Register</h2>
             </div> 
        <form method="post" action="register.php">
            <div class="input-group">
                <label>Username</label>
                <input type="text" name="username" value="">

            </div>

            <div class="input-group">
                <label>Email</label>
                <input type="text" name="Email" value="">
            </div>

            <div class="input-group">
                <label>Password</label>
                <input type="password" name="Password_1">
            </div>


            <div class="input-group">
                <label>Confirm Password</label>
                <input type="password" name="password_2">
            </div>
            <div class="input-group">
                
                <button type="submit" name="Register" class="btn">Register</button>
            </div>
            <p>
                Already a member? <a href="login.php">Sign in</a>
            </p>



        </form>  
        </div> 
</body>
</html>
