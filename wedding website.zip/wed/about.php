<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>about us</title>
	<link rel="stylesheet" type="text/css" href="ab.css">
	<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" />
</head>
<body>	        <header>
        <h1>wed-happy</h1>
        <nav>
            <ul class="nav-area">
<li><a href="index.php">home</a></li>
<li><a href="about.php">About</a></li>
<li><a href="services.php">services</a></li>
<li><a href="contact.php">contact</a></li>
<li><a href="our team.php">team</a></li>
</ul>
</nav>
        <a href="login.php" class="btn-area">login</a>
    </header>
<div class="section">
	<div class="container">
		<div class="c-section">
			<div class="title">
			<h2>about us</h2>
		    </div>
		    <div class="content">
		    	<h2>wedding planners</h2>
		    	<p>hello evryone, this is royal wedding planners, we are glad that you make visit to us, we are here to provide all services of wedding .<br>
		    	so you have any queries or required any help you can directly contact us we have given a mesage box were you can call or message us directly .x </p>

<div class="button">
	<a href="">read more</a>
</div>
</div></div>
<div class="img-section">
	<img src="wed.png">
</div>
	</div>
</div>





</body>
</html>