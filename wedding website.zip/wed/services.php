<!DOCTYPE html>
<html>
<head>
        <meta charset="utf-8">
        <title>dd</title>
        <link rel="stylesheet" type="text/css" href="style1.css">
        
</head>
<body>

<header>
        <h1>wed-happy</h1>
        <nav>
            <ul class="nav-area">
<li><a href="index.php">home</a></li>
<li><a href="about.php">About</a></li>
<li><a href="services.php">services</a></li>
<li><a href="contact.php">contact</a></li>
<li><a href="our team.php">team</a></li>
</ul>
</nav>
        <a href="login.php" class="btn-area">login</a> 
</header>
   
    <div class="wrapper">
            <h1>your wish our creation</h1>
            <p>we are here to make your wedding more memoriable</p>

  
    <div class="content-box">
            <div class="card">
                   
                    <h2>DECOR AND DESIGN</h2>
                    <p> you can select what type of decor you want</p>
            </div>
             <div class="card">

                    <h2>FOOD AND BEVEERAGES</h2>
                    <p>all types of dishes/veg/non-veg</p>
            </div>

             <div class="card">

                    <h2>STYLING</h2>
                    <p>differnt plans are availble  </p>
            </div>
             <div class="card">

                    <h2>PRE WEDDING </h2>
                    <p>all pre wedding plans will be excuted</p>
            </div> 
            <div class="card">
                    <h2>music with best photoghrapher </h2>
                    <p></p>
            </div> 
            <div class="card">

                    <h2>ENTERTAINTMENT</h2>
                    <p>dgdgdggd dgdgdggd dgdgd gd dgshshd </p>
            </div>
           
    
    </div>
  </div>
</body>
</html>