<?php
	$firstname = $_POST['firstname'];
$middlename = $_POST['middlename'];
	$lastname = $_POST['lastname'];
	$email = $_POST['email'];
	$password = $_POST['password'];
        $address = $_POST['address'];
$contact = $_POST['contact'];
	$date = $_POST['date'];
	
	
	
	header('location:index.php');
	
	
	//Database connection_aborte
	$conn = new mysqli('127.0.0.1','root','','project');
	if($conn->connect_error)
	{
		die('connection Failed :'.$conn->_error);
	}else
	{
		$stmt = $conn->prepare("insert into register(firstname,middlename,lastname,email,password,address,contact,date) values(?,?,?,?,?,?,?,?)");
		$stmt->bind_param("ssssssii",$firstname,$middlename,$lastname,$email,$password,$address,$contact,$date);
		$stmt->execute();
		echo"registration Successfully...";
		$stmt->close();
		$conn->close();
	}
?>